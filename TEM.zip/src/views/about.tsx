import React, { FC } from 'react';



export const About: FC = () => {
    return (
        <h2>About us </h2>
    );
}