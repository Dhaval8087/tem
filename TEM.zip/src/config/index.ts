const API_URL = 'http://localhost:5000/db'
export { API_URL }