import { combineReducers } from 'redux';

import eventsReducer from './eventsreducer';


const rootReducer = combineReducers({
    eventsReducer
});
export default rootReducer;